statusnew = "";
objects = [];
//    document.getElementById("status").innerHTML = "Status : Detecting Objects "


function preload(){
     babyalarm =  loadSound("call-to-attention-123107.mp3")
}

function setup() {
    canvas = createCanvas(600, 420);
    canvas.center();

    video = createCapture(VIDEO)
    video.size(600, 420);
    video.hide()
}

function start() {
}


function gotResults(error, results) {
    if (error) {
        console.error(error)
    } else {
        console.log(results)
        objects = results;
    }
}

function draw() {
    image(video, 0, 0, 600, 420);


    if (statusnew != '') {

        for (i = 0; i < objects.length; i++) {
            document.getElementById("status").innerHTML = "Status : Objects Detected "
            object_name = objects[i].label
            percent = floor(objects[i].confidence * 100)
            position_x = objects[i].x
            position_y = objects[i].y
            width = objects[i].width
            height = objects[i].height

            if (object_name == "person") {
                document.getElementById("numberofobjects").innerHTML = "Baby Found"
                fill("blue");
                textSize(35);
                text(object_name, position_x + 20, position_y + 20);
                noFill();
                stroke("green");
                rect(position_x, position_y, width, height);
            }
            else{
                document.getElementById("numberofobjects").innerHTML = "Baby Not Found"
                 babyalarm.play();
            }


        }
        
        if(objects.length == 0){
            document.getElementById("numberofobjects").innerHTML = "Baby Not Found"
            babyalarm.play();
        }
    }
}

function modelLoaded() {
    console.log("Model has been successfully loaded!")
    statusnew = true;
    objectdetector.detect(video, gotResults)
}
